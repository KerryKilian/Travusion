
(function init() {
  "use strict";

  const offers = Array.from(document.getElementsByClassName("offer"));

  function loadOffers(entries, observer) {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("loadVisible");
        observer.unobserve(entry.target); // Stop observing once the offer is visible
      }
    });
  }

  const options = {
    root: null,
    rootMargin: "0px",
    threshold: [0.1],
  };

  const observer = new IntersectionObserver(loadOffers, options);

  offers.forEach((offer) => {
    observer.observe(offer);
  });


  // when document loaded
  document.addEventListener("DOMContentLoaded", function() {
    const h1 = document.querySelector(".title__h1");
    const figure = document.querySelector(".title__figure");
    h1.classList.add("translate");
    figure.classList.add("translate");
  });
})();